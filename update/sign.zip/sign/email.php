<?php
/* 
//BY ZODIAC
#------------------------------[VSCAM - SENDER]------------------------------#
*/
$email = "hmedhosny55@gmail.com"; // REPLACE TO YOUR MAIL ! ;)
//print ur mail ""
?>
